import sys
import re
from antlr4 import *
from cminusLexer import cminusLexer
from cminusParser import cminusParser
from cminusListener import cminusListener

IDENT_SIZE = 2

class printTree(cminusListener):
    def __init__(self):
        self.ident = 0

    def enterVar_declaracao(self, ctx:cminusParser.Var_declaracaoContext):
        self.ident += IDENT_SIZE
        if (ctx.ID() != None):
            print(' ' * self.ident, ctx.ID())
        if (ctx.NUM() != None):
            print(' ' * self.ident, ctx.NUM())
        pass

    def exitVar_declaracao(self, ctx:cminusParser.Var_declaracaoContext):
        self.ident -= IDENT_SIZE
        pass

    def enterTipo_especificador(self, ctx: cminusParser.Tipo_especificadorContext):
        self.ident += IDENT_SIZE
        if(ctx.VOID() != None):
            print(' ' * self.ident,ctx.VOID())
        if (ctx.INT() != None):
            print(' ' * self.ident,ctx.INT())
        pass

    def exitTipo_especificador(self, ctx: cminusParser.Tipo_especificadorContext):
        self.ident -= IDENT_SIZE
        pass

    def enterFun_declaracao(self, ctx: cminusParser.Fun_declaracaoContext):
        self.ident += IDENT_SIZE
        if (ctx.ID() != None):
            print(' ' * self.ident, ctx.ID())
        pass

    def exitFun_declaracao(self, ctx: cminusParser.Fun_declaracaoContext):
        self.ident -= IDENT_SIZE
        pass

    def enterParams(self, ctx:cminusParser.ParamsContext):
        self.ident += IDENT_SIZE
        if (ctx.VOID() != None):
            print(' ' * self.ident, ctx.VOID())
        pass

    def exitParams(self, ctx:cminusParser.ParamsContext):
        self.ident -= IDENT_SIZE
        pass

    def enterParam(self, ctx:cminusParser.ParamContext):
        self.ident += IDENT_SIZE
        if (ctx.ID() != None):
            print(' ' * self.ident, ctx.ID())
        pass

    def exitParam(self, ctx:cminusParser.ParamContext):
        self.ident -= IDENT_SIZE
        pass


    def enterSelecao_decl(self, ctx:cminusParser.Selecao_declContext):
        self.ident += IDENT_SIZE
        if (ctx.IF() != None):
            print(' ' * self.ident, ctx.IF())
        if (ctx.ELSE() != None):
            print(' ' * self.ident, ctx.ELSE())
        pass

    def exitSelecao_decl(self, ctx:cminusParser.Selecao_declContext):
        self.ident -= IDENT_SIZE
        pass

    def enterIteracao_decl(self, ctx:cminusParser.Iteracao_declContext):
        self.ident += IDENT_SIZE
        if (ctx.WHILE() != None):
            print(' ' * self.ident, ctx.WHILE())
        pass

    def exitIteracao_decl(self, ctx:cminusParser.Iteracao_declContext):
        self.ident -= IDENT_SIZE
        pass

    def enterRetorno_decl(self, ctx:cminusParser.Retorno_declContext):
        self.ident += IDENT_SIZE
        if (ctx.RETURN() != None):
            print(' ' * self.ident, ctx.RETURN())
        pass

    def exitRetorno_decl(self, ctx:cminusParser.Retorno_declContext):
        self.ident -= IDENT_SIZE
        pass

    def enterExpressao(self, ctx: cminusParser.ExpressaoContext):
        self.ident += IDENT_SIZE
        if (ctx.ASSIGN() != None):
            print(' ' * self.ident, ctx.ASSIGN())
        pass

    def exitExpressao(self, ctx: cminusParser.ExpressaoContext):
        self.ident -= IDENT_SIZE
        pass

    def enterVar(self, ctx:cminusParser.VarContext):
        self.ident += IDENT_SIZE
        if (ctx.ID() != None):
            print(' ' * self.ident, ctx.ID())
        pass

    def exitVar(self, ctx:cminusParser.VarContext):
        self.ident -= IDENT_SIZE
        pass

    def enterRelacional(self, ctx:cminusParser.RelacionalContext):
        self.ident += IDENT_SIZE
        if (ctx.LETHAN() != None):
            print(' ' * self.ident, ctx.LETHAN())
        if (ctx.LT() != None):
            print(' ' * self.ident, ctx.LT())
        if (ctx.GT() != None):
            print(' ' * self.ident, ctx.GT())
        if (ctx.GETHAN() != None):
            print(' ' * self.ident, ctx.GETHAN())
        if (ctx.EQ() != None):
            print(' ' * self.ident, ctx.EQ())
        if (ctx.DF() != None):
            print(' ' * self.ident, ctx.DF())
        pass

    def exitRelacional(self, ctx:cminusParser.RelacionalContext):
        self.ident -= IDENT_SIZE
        pass

    def enterSoma(self, ctx:cminusParser.SomaContext):
        self.ident += IDENT_SIZE
        if (ctx.PLUS() != None):
            print(' ' * self.ident, ctx.PLUS())
        if (ctx.MINUS() != None):
            print(' ' * self.ident, ctx.MINUS())
        pass

    def exitSoma(self, ctx:cminusParser.SomaContext):
        self.ident -= IDENT_SIZE
        pass

    def enterTermo(self, ctx:cminusParser.TermoContext):
        self.ident += IDENT_SIZE
        print(' ' * self.ident)
        pass

    # Exit a parse tree produced by cminusParser#termo.
    def exitTermo(self, ctx:cminusParser.TermoContext):
        self.ident -= IDENT_SIZE
        pass

    def enterMult(self, ctx:cminusParser.MultContext):
        self.ident += IDENT_SIZE
        if (ctx.TIMES() != None):
            print(' ' * self.ident, ctx.TIMES())
        if (ctx.OVER() != None):
            print(' ' * self.ident, ctx.OVER())
        pass

    def exitMult(self, ctx:cminusParser.MultContext):
        self.ident -= IDENT_SIZE
        pass

    def enterFator(self, ctx:cminusParser.FatorContext):
        self.ident += IDENT_SIZE
        if (ctx.NUM() != None):
            print(' ' * self.ident, ctx.NUM())
        pass

    def exitFator(self, ctx:cminusParser.FatorContext):
        self.ident -= IDENT_SIZE
        pass

    def enterAtivacao(self, ctx:cminusParser.AtivacaoContext):
        self.ident += IDENT_SIZE
        if (ctx.ID() != None):
            print(' ' * self.ident, ctx.ID())
        pass

    def exitAtivacao(self, ctx:cminusParser.AtivacaoContext):
        self.ident -= IDENT_SIZE
        pass



def main(argv):
    input = FileStream(argv[1])
    lexer = cminusLexer(input)
    stream = CommonTokenStream(lexer)
    parser = cminusParser(stream)
    tree = parser.programa()
    #tree_str = tree.toStringTree(recog=parser)
    #print(tree_str)

    printer = printTree()
    walker = ParseTreeWalker()
    walker.walk(printer, tree)


if __name__ == '__main__':
    main(sys.argv)
